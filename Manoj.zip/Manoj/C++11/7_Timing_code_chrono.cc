/*
 * 7_Timing_code_chrono.cc
 *
 *  Created on: Aug 4, 2019
 *      Author: user1
 */

#include <iostream>
#include <chrono>

using namespace std;



