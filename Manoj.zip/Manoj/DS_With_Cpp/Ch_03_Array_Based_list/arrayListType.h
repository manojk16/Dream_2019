//
// Created by redbend on 12/09/2019.
//

#ifndef ARRAYLISTTYPE_H
#define ARRAYLISTTYPE_H
#include <iostream>
using namespace std;
template<class Type>
class arrayListType{
private:
    Type *list; //array to hold the list elements
    int length; //to store the length of the list
    int maxSize;
public:
    //assignment operator Overloads
    const arrayListType<Type>&operator=(const arrayListType<Type>& other);
    bool isEmpty() const;
    bool isFull() const;
    int listsize() const;
    int maxListSize() const;
    void print();
    void insert(const Type&);
    int seqSearch(const Type&);
    void removeItem(const Type&);
    void removeAt(int loc);
    arrayListType(int maxsize=100);
    // copy constructor
    arrayListType(const arrayListType<Type> &);
    ~arrayListType();


};
template <class Type>
bool arrayListType<Type>::isEmpty() const {
    return (length==0);
}
template <class Type>
bool arrayListType<Type>::isFull()const {
    return (length==maxSize);
}
template <class Type>
int arrayListType<Type>::listsize() const {

    return length;

}
template <class Type>
int arrayListType<Type>::maxListSize() const {

    return maxSize;

}

template <class Type>
void arrayListType<Type>::print() {
    for(int i =0;i<length;i++)
    {
        cout << list[i]<<" " ;
    }
    cout << endl;
}
template <class Type>
arrayListType<Type>::arrayListType(int size) {
    if(size<0){
        maxSize=100;
    }else{
        maxSize=size;
    }
    length=0;
    list = new Type[maxSize];

}
template <class Type>
arrayListType<Type>::~arrayListType(){
    delete [] list;
}
template <class Type>
arrayListType<Type>::arrayListType(const arrayListType<Type> &other) {
    maxSize=other.maxSize;
    length=other.length;
    list = new Type[other.maxSize];
    for(int j=0;j<length;j++){
        list[j]=other.list[j];
    }

}
template <class Type>
const arrayListType<Type>& arrayListType<Type>::operator=(
        const arrayListType<Type> &other) {
    if(&other!=this) {
        delete[] list;

        maxSize = other.maxSize;
        length = other.length;
        for (int i = 0; i < length; i++) {
            list[i] = other.list[i];
        }
    }else{
        return *this;
    }
}
template <class Type>
void arrayListType<Type>::insert(const Type& newItem)  {
    int loc;
    if(length==0){
        list[length++]=newItem;
    } else if(length==maxSize){
        cerr << "Can Not  Insert the element \n";
    }else{
        list[length++]=newItem;
    }
}

template <class Type>
void arrayListType<Type>::removeAt(int location){
    if (location < 0 || location >= length)
        cout << "The location of the item to be removed "
             << "is out of range" << endl;
    else
    {
        for (int i = location; i < length - 1; i++)
            list[i] = list[i+1];
        length--;
    }
}
template <class Type>
int arrayListType<Type>::seqSearch(const Type &item) {
    int loc;
    bool found=false;
    for(loc=0;loc<length;loc++){
        if(list[loc]==item){
            found =true;
            break;
        }
    }
    if(found){
        return loc;
    }else{
        return -1;
    }
}
template <class Type>
void arrayListType<Type>::removeItem(const Type &item) {
    int loc;
    if(length==0){
        cerr << "Can Not remove as Link list is empty \n";
    }else{
        loc=seqSearch(item);
        if(loc!=-1){
            removeAt(loc);
        }else{
            cerr <<"Item doen't exist into the array\n";
        }
    }

}
#endif
