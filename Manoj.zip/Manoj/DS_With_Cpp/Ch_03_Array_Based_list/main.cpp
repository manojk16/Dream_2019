#include <iostream>
#include "arrayListType.h"

int main(){
    arrayListType<int> array(10);
    array.insert(10);
    array.insert(20);
    array.insert(30);
    array.insert(40);
    array.insert(50);
    array.print();
    return  0;
}