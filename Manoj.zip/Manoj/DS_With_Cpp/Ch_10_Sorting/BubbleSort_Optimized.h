//
// Created by redbend on 17/09/2019.
//

#ifndef SORTING_BUBBLESORT_OPTIMIZED_H
#define SORTING_BUBBLESORT_OPTIMIZED_H

#include "arrayListType.h"
#endif //SORTING_BUBBLESORT_OPTIMIZED_H
template <class Type>
void arrayListType<Type>::bubbleSort() {
    for(int k=0; k<m_length-1;k++){
        // 1.
        // we will not run inner loop all the way up no n-2 because at any time of sorting array will have some part already sorted so
        // for that we will not used for(int i=0;i<=n-2;i++) // here we are taking n-2 because if we will put n-1 then in condition if(A[i] > A[i+1]) A[i+1] will go out of range so n-2 is correct
        // But in first pass loop will ggo uo tp n-2 and in this pass hieghest element will be at its place so in next pass if loop is going upto n-3 then it is fine and so on so this loop should be as follows

        // 2. In some cases data can be sort much before then the totoal number of passes bcz total number of passes is upto n-1 so some passes are trying to sort already sorted array .
        // Here inner loop going throug the element without swapping bcz if condition is not matching
        // for that let use a flag and if element getting swapped then make it True if not then outside the inner loop if it is False and break means now elements rae already sorted so no further passes required
        // so by this bubble sort can be improved and inner loop totoal time will be in in already sorted array means best case and in that case complexity will be order (n)
        bool flag=false; //
        for(int i=0;i<m_length-k-1;i++){
            if(m_list[i] > m_list[i+1]){
                swapitem(i,i+1);
                flag=true;
            }
        }
        if(flag==false)
            break;

    }
}
