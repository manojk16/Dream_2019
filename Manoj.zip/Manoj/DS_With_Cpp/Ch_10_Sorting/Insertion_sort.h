//
// Created by redbend on 16/09/2019.
//

#ifndef SORTING_INSERTION_SORT_H
#define SORTING_INSERTION_SORT_H
#include "arrayListType.h"
template <class Type>
void arrayListType<Type>::insertionSort()
{
    int firstoutOfOrder,loc;
    Type  temp;
    for(firstoutOfOrder=1;firstoutOfOrder<m_length;firstoutOfOrder++)
        if(m_list[firstoutOfOrder]<m_list[firstoutOfOrder-1]){
            temp=m_list[firstoutOfOrder];
            loc=firstoutOfOrder;

        do{
            m_list[loc]=m_list[loc-1];
            loc--;
        }while(loc > 0 && m_list[loc-1] > temp);
        m_list[loc]=temp;
    }

}
#endif //SORTING_INSERTION_SORT_H
