//
// Created by redbend on 16/09/2019.
//
//Algorithm :
// 1. The quick_Sort are based on devide and conquer to sort a lsit
// 2. This list is partitioned into 2 sublist and these2 sublist are further  sorted and combined in such a way that combined list is sorted out
// // Algorithm :
/*
if (list size is greater than 1 )
    partition the list in to two sublist
            1. lowerSublist and Uper Sublist
            2. Quicksort lowersublist.
            3. Quicksort UpperList
            4. Combined the sorted lowersublist and UpperSublist

*/
// There are number of ways to select the Pivot, But Genrally it is chosen in such a way that both list are of equal size.
//The partition algorithm is as follows: (We assume that pivot is chosen as the middle
//element of the list.)
// 1.   Determine the Pivot and swap the first element with Pivot
//      Suppose that the index smallIndex points to the last element smaller
//      than the pivot. The index smallIndex is initialized to the first element
//      of the list.
// 2. For the remaining elements in the list (starting at the second element)
//      If the current element is smaller than the pivot
//          a. Increment smallIndex.
//          b. Swap the current element with the array element pointed to by smallIndex
// 3. Swap the first element, that is, the pivot, with the array element
//pointed to by smallIndex.
#ifndef SORTING_QUICKSORT_H
#define SORTING_QUICKSORT_H
#include "arrayListType.h"
template <class Type>
int arrayListType<Type>::partition(int first, int last) {
    cout << "In Partition \n";
    Type pivot;
    int i,j;// i=smallindes, j=index: smallIndex == will point to the last elemnt of lowersublist while index will point the next element to be swapped
    //pivot=rand(m_list[first],m_list[last]);
    pivot=m_list[first];
    i=first;
    for(j=first+1;j<=last;j++){
        if(m_list[j] <= pivot){
            i++;
            swapitem(i,j);
        }
    }
    swapitem(first,i);
    return i;


}
template <class Type>
void arrayListType<Type>::recQuickSort(int first, int last) {
    cout << "In recQucikSort \n";
    int partitionLoc;
    if(first<last) {
        partitionLoc=partition(first,last);
        recQuickSort(first, partitionLoc-1);
        recQuickSort(partitionLoc + 1, last);
    }

}
template <class Type>
void arrayListType<Type>::quickSort(){
    cout << "In QucikSort \n";
    recQuickSort(0,m_length-1);
}
#endif //SORTING_QUICKSORT_H
