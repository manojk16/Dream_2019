//
// Created by redbend on 14/09/2019.
//

#ifndef _SORTING_ARRAY_H
#define _SORTING_ARRAY_H
#include <iostream>
#include <algorithm>

using namespace std;

template <class Type>
class arrayListType{
private:
    Type *m_list;
    int m_length;
    int m_maxsize;
    void swapitem(int first, int second);
    int minLocation(int first, int last);
    int partition(int first, int last);
    void recQuickSort(int first,int last);
public:

    arrayListType(int size=100);
    void insert(const Type &item);


    void selectionSort();
    void insertionSort();
    void quickSort();
    void bubbleSort();
    void print();

    //copy constructor
    arrayListType(const arrayListType<Type> &);
    // assigment operator
    const arrayListType<Type>&operator=(const arrayListType<Type> & other);

    ~arrayListType();
};
template <class Type>
arrayListType<Type>::~arrayListType() {
    cout << "Distructor called \n";
    delete [] m_list;
}
template <class Type>
arrayListType<Type>::arrayListType(int size) {
    m_maxsize=size;
    m_length=0;
    m_list= new Type[m_maxsize];
}
// copy constructor
template <class Type>
arrayListType<Type>::arrayListType(const arrayListType<Type> &other) {
    m_length= other.m_length;
    m_maxsize=other.m_maxsize;
    m_list = new Type[other.m_maxsize];

    for(int i=0;i<other.m_length;i++){
        m_list[i]=other.m_list[i];
    }

}
// assignment Operator
template <class Type>
const arrayListType<Type>& arrayListType<Type>::operator=(
        const arrayListType<Type> &other) {
    if(this!=&other){
        delete [] m_list;
        m_length= other.m_length;
        m_maxsize=other.m_maxsize;
        m_list = new Type[other.m_maxsize];

        for(int i=0;i<other.m_length;i++){
            m_list[i]=other.m_list[i];
        }
    } else{
        return *this;
    }
}

template <class Type>
void arrayListType<Type>::print() {
    for(int i=0;i<m_length;i++){
        cout << m_list[i] << " ";
    }
    cout <<endl;
}

template <class Type>
void arrayListType<Type>::insert(const Type &item) {
    int loc;
    //cout << "Item is " << item <<endl;
    if(m_length==0){
        m_list[m_length++]=item;
    }else if(m_length==m_maxsize){
        //cout << "Length is " << m_length <<endl;
        cerr<<"Item can not be inserted\n";
    }else{
        m_list[m_length++]=item;

    }
}
template <class Type>

void arrayListType<Type>::swapitem(int first, int second) {
    /*first=first+second;
    second=first-second;
    first=first-second;*/
  //  cout << "In Swap " <<"\n";
    Type temp;
    temp=m_list[first];
    m_list[first]=m_list[second];
    m_list[second]=temp;
}

// Return the index of min Item
template <class Type>
int arrayListType<Type>::minLocation(int first, int last) {
    int minIndex;
    minIndex=first;
    for(int loc=first+1;loc<last;loc++){
        if(m_list[loc] < m_list[minIndex]){
            minIndex=loc;
        }
    }
    return minIndex;
}
template <class Type>
void arrayListType<Type>::selectionSort() {
    // Selection Sort Algo : having only 2 parts
    // 1. Find the location, smallestIndex, of the smallest element in
    //list[index]...list[length - 1].
    //2.Swap the smallest element with list[index]. That is, swap
    //list[smallestIndex] with list[index].

    int minIndex;
    for(int loc=0;loc<=m_length-1;loc++){
        minIndex=minLocation(loc,m_length-1);
        swapitem(loc,minIndex);
    }
}

#endif





























