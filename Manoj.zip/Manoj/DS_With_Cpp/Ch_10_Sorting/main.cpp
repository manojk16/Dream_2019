#include <iostream>
#include "QuickSort.h"
#include "Insertion_sort.h"
#include "BubbleSort_Optimized.h"
int main() {
    std::cout << "Hello, World Of sorting" << std::endl;
    arrayListType<int> list;
    int num;
    cout << "Enter the Number not ending with -999"<<endl;
    cin >> num;
    while(num!=-999){
        list.insert(num);
        cin>>num;
    }
    cout << "list before  Sort " <<endl;
    list.print();
    cout << "List After  Sort " <<endl;
   // list.selectionSort();
   //list.quickSort();
   list.bubbleSort();
    list.print();

    return 0;
}