#include <iostream>


using namespace std;



class arraylist{
	int m_length;
	int m_maxSize;
	int *m_list;
	void swapitem(int first, int second){
		int temp;
		temp=m_list[first];
		m_list[first]=m_list[second];
		m_list[second]=temp;
	}
	int minLocation(int first, int last){
		int minIndex;
		minIndex=first;
		for(int loc=first+1;loc<last;loc++){
			if(m_list[loc] < m_list[minIndex])
				minIndex=loc;
		}
		return minIndex;
	}

public:
	arraylist(int size=100){
		m_maxSize=size;
		m_length=0;
		m_list = new int[size];
	}
	//copy constructor
	arraylist(const arraylist& other){
		m_maxSize=other.m_maxSize;
		m_length = other.m_length;
		m_list = new int[other.m_maxSize];
		for(int i=0; i<other.m_length; i++)
		{
			m_list[i]=other.m_list[i];
		}
	}
	// assignment Operatror
	const arraylist& operator=(const arraylist& other){
		if(this!=&other){
			delete [] m_list;
			m_maxSize=other.m_maxSize;
			m_length = other.m_length;
			m_list = new int[other.m_maxSize];
		for(int i=0;i<other.m_length;i++)
			{
				m_list[i]=other.m_list[i];
			}

		}else{
			return *this;
		}
	}
	void insert(int newItem){
		if(m_length==m_maxSize){
			cout << "It is full Not allowed furhter item Insertion \n";
		}
		m_list[m_length++]=newItem;
	}
	// selection sort	
	void selectionSort(){
		int minIndex;
		for(int loc=0;loc<m_length;loc++){
			minIndex=minLocation(loc,m_length);
			swapitem(loc,minIndex);
		}

	}
	void print(){
		for(int i=0;i<m_length;i++){
			cout << m_list[i]<<" ";
		}
		cout << "\n";
	}
	void insertionsort(){

    int firstoutOfOrder,loc;
    int  temp;
    for(firstoutOfOrder=1;firstoutOfOrder<m_length;firstoutOfOrder++){
        if(m_list[firstoutOfOrder]<m_list[firstoutOfOrder-1]){
            temp=m_list[firstoutOfOrder];
            loc=firstoutOfOrder;

        do{
            m_list[loc]=m_list[loc-1];
            loc--;
        }while(loc > 0 && m_list[loc-1] > temp);
        m_list[loc]=temp;
    }
	}

}
	
};


int main(){
	arraylist array(10);
	array.insert(2);
	array.insert(17);
	array.insert(7);
	array.insert(0);
	array.insert(10);
	array.insert(98);
	array.insert(52);
	array.insert(40);
	array.insert(4);
	array.print();
	//array.selectionSort();
	array.insertionsort();
	array.print();



}