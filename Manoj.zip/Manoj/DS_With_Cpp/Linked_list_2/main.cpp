#include <iostream>
#include "linkedlistIterator.h"
#include "linkedlistIterator.cpp"


int main() {
    cout<< "Hello Linked list world " << endl;
    return 0;
}
