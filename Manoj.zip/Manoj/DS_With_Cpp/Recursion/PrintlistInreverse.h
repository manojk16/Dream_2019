//
// Created by redbend on 11/09/2019.
//

#ifndef RECURSION_PRINTLISTINREVERSE_H
#define RECURSION_PRINTLISTINREVERSE_H
#include <iostream>
#include <list>
/*oid reverseprintlist(std::list<int> &linklist){
    std::list<int>::iterator current;
    current=linklist.begin();

   // std::auto current=linklist.begin();
    if(current!=NULL){
        reverseprintlist(current->next);
        std::cout << current->data <<std::endl;

    }
}*/
#endif //RECURSION_PRINTLISTINREVERSE_H
