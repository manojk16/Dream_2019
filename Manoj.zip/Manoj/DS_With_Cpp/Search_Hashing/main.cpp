#include <iostream>
#include "arrayListType.h"

int main() {
    std::cout << "Hello, World!" << std::endl;
    std::cout << "Hello, Welcome to Searching Algorithm " << std::endl;
    arrayListType<int> array(20);
    array.insert(10);
    array.insert(400);
    array.insert(30);
    array.insert(350);
    array.insert(25);
    array.insert(15);
    array.insert(45);

    array.print();
    cout << "Found the item =30 using Seq search " << "The location of the item is " << array.seqSearch(30) << endl;

    cout << "Found the item =45 using binary search " << "The location of the item is" << array.binarySearch(45) << endl;



    return 0;
}