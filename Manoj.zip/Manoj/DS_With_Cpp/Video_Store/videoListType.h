//
// Created by redbend on 10/09/2019.
//

#ifndef VIDEO_STORE_VIDEOLISTTYPE_H
#define VIDEO_STORE_VIDEOLISTTYPE_H
#include "VideoType.h"
#inlude 
class videoListType{
public:
    list<videoType *> vlist;

};
#endif //VIDEO_STORE_VIDEOLISTTYPE_H
