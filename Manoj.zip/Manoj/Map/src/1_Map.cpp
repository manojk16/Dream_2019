//============================================================================
// Name        : 1_Map.cpp
// Author      : Manoj
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================
// 1.  Map is an associative container where it store the element in the form of key value pair

// 2. It store only unique keys and that is in sorted order
// 3. Searching in the map is done based on the unique sorted key so it is very fast and logrithimic time
// 4. Map might be implemented using balanced binary tree

#include <iostream>
#include <map>
#include <algorithm>
#include <vector>

using namespace std;

int main() {
	cout << "!!!Hello World of Map !!!" << endl; // prints !!!Hello World!!!
	map<string,int> mapofWords;
	mapofWords.insert(make_pair("Earth",1));
	mapofWords.insert(make_pair("Sun",2));
	mapofWords.insert(make_pair("Moon",3));
	mapofWords["Sun"]=4;
	mapofWords["Earth"]=5;
	map<string,int> :: iterator it= mapofWords.begin();
	//print the data stored into map
	while(it!=mapofWords.end()){
		cout << it->first << " :: " << it->second <<endl;
		it++;
	}
	//check if the insertion is successfull or not
	if(mapofWords.insert(make_pair("Earth",1)).second==false){
		cout << "Element with the key Earth not inserted because it is already existed "<<endl;
	}
	// find some element into Map

	if(mapofWords.find("Sun")!=mapofWords.end()){
		cout << "Element found" <<endl;

	}
	if(mapofWords.find("Mars")==mapofWords.end()){
		cout << "Elements  not found " <<endl;
	}

	return 0;
}
