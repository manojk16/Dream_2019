/*
 * 2_Map_find_by_Value.cpp
 *
 *  Created on: Oct 11, 2019
 *      Author: Manoj
 */
#include <map>
#include <algorithm>
#include <iostream>
using namespace std;

map<string, int>::iterator findByValue(map<string,int> &mapOfWords,int value){
	map<string,int>::iterator it=mapOfWords.begin();
	while(it!=mapOfWords.end()){
		if(it->second==value){
			return it;
		}
		it++;
	}

}
int main(){
	map<string,int> mapOfWords;
	mapOfWords.insert(make_pair("Earth",1));
	mapOfWords.insert(make_pair("Moon",2));
	mapOfWords.insert(make_pair("Sun",3));
	mapOfWords.insert(make_pair("Mars",4));
	map<string,int>::iterator it=mapOfWords.begin();
	it=findByValue(mapOfWords,2);
	if(it!=mapOfWords.end()){
		cout << it->first << " :: " << it->second <<endl;
	}
}



