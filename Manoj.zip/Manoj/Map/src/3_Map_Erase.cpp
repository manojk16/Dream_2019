/*
 * 3_Map_Erase.cpp
 *
 *  Created on: Oct 11, 2019
 *      Author: Manoj
 *  void erase (iterator position);  // Erasing by itr pos
	size_type erase (const key_type& k); // Erasing by key
	void erase (iterator first, iterator last); // Erase Map
*/

#include <iostream>
#include <map>
#include <vector>

using namespace std;

int main(){
	map<string, int> mapOfWords;
	mapOfWords.insert(make_pair("Earth",1));
	mapOfWords.insert(make_pair("Moon",2));
	mapOfWords.insert(make_pair("Sun",3));
	mapOfWords["Earth"]=4;
	map<string,int>::iterator it=mapOfWords.find("Moon");
	mapOfWords.erase(it);
	while(it!=mapOfWords.end()){
		cout << it->first<<" :: " << it->second <<endl;
		it++;
	}
	mapOfWords.erase("Earth");
	while(it!=mapOfWords.end()){
			cout << it->first<<" :: " << it->second <<endl;
			it++;
		}

}


