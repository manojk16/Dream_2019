/*
 * 4_External_Sorting_Criteria.cpp
 *
 *  Created on: Oct 11, 2019
 *      Author: user1
 */
// External sorting criteria:
#include <iostream>
#include <map>
#include <algorithm>

using namespace std;
class WordComparator{
public:
	bool operator()(const string &left, const string &right){
		return(left > right);
	}
};
int main(){
	map<string,int,WordComparator> mapofWords_2;
	mapofWords_2.insert(make_pair("Earth",1));
	mapofWords_2.insert(make_pair("Moon",2));
	mapofWords_2.insert(make_pair("Sun",3));
	map<string,int,WordComparator>::iterator it=mapofWords_2.begin();
	for(;it!=mapofWords_2.end();it++){
		cout << it->first<<" ------------" << it->second <<endl;


	}

}



