/*
 * 5_UsrDefined_Class_Object_Key.cpp
 *
 *  Created on: Oct 11, 2019
 *      Author: Manoj
 */


 #include <iostream>
 #include <map>
 #include <algorithm>

 using namespace std;

class User {
	string m_name;
	string m_id;
public:
	User(string name, string id) :
		m_name(name), m_id(id)
	{
	}
	const string& getName() const
	{
		return m_name;
	}
	const string& getID() const
	{
		return m_id;
	}
	bool operator<(const User &userObj) const
	{
		if (userObj.m_id < this->m_id)
		{
			return true;
		}
	}
};


 void example_1()
{
	map<User, int> m_UserInfoMap;
	m_UserInfoMap.insert(make_pair<User, int>(User("Mr, X", "3"), 100));
	m_UserInfoMap.insert(make_pair<User, int>(User("Mr, Y", "10"), 200));
	m_UserInfoMap.insert(make_pair<User, int>(User("Mr. Z", "20"), 300));
	map<User, int>::iterator itr = m_UserInfoMap.begin();
	for (; itr != m_UserInfoMap.end(); itr++)
	{
		cout << itr->first.getName() << " : : " << itr->second << std::endl;
	}
}


 struct UserNameComparator{
 bool operator()(const User &left, const User &right){
 return (left.getName() > right.getName());
 }
 };
 void example_2(){
 map<User,int,UserNameComparator> m_UserInfoMap;
 m_UserInfoMap.insert(make_pair<User,int>(User("Mr. X","3"),100));
 m_UserInfoMap.insert(make_pair<User,int>(User("Mr. Y","10"),200));
 m_UserInfoMap.insert(make_pair<User,int>(User("Mr, Z","20"),300));
 map<User,int,UserNameComparator>::iterator itr=m_UserInfoMap.begin();
 for(;itr!=m_UserInfoMap.end();++itr){
 cout << itr->first.getName()<<" >>>>>>> " << itr->second <<endl;
 }
 }

 int main(){
 cout << "Comparing by ID " << endl;
 example_1();
 cout << "Comparing by Name " << endl;
 example_2();
 }


