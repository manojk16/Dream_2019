//
// Created by redbend on 17/09/2019.
//

#ifndef PART_0_FUNCTION_OBJECT_EXAMPLE_FUNCTOR_H
#define PART_0_FUNCTION_OBJECT_EXAMPLE_FUNCTOR_H
// Abstract class
class Binaryfunction{
public:
    Binaryfunction(){}
    virtual double operator()(double left, double right)=0;
};
class Add:public Binaryfunction{
public:
    Add(){}
    virtual double operator()(double left, double right){
        return left+right;
    }
};

class Multiply:public Binaryfunction{
public:
    Multiply(){}
    virtual double operator()(double left, double right){
        return left*right;
    }
};

double bin_op(double left, double right, Binaryfunction* binFunction){
    return (*binFunction)(left, right);
}
#endif //PART_0_FUNCTION_OBJECT_EXAMPLE_FUNCTOR_H
