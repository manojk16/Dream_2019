#include <iostream>
#include "Example_Functor.h"
// function Objects()  functiors:->A function Object allows an instance object of a class can be called as similiar to a normal function and it is carried out be overloading operator().
// The main benifits the function object that they are objects and so can contain state
int main() {
    std::cout << "Hello, World! of Functors or Function Objects " << std::endl;
    double a=2.10;
    double b=3.90;
    Binaryfunction *pAdd=new Add();
    Binaryfunction *pMulti= new Multiply();
    std::cout << "Add : " << bin_op(a,b,pAdd)<<std::endl;
    std::cout << "Multiply : " << bin_op(a,b,pMulti)<<std::endl;
    return 0;
}
