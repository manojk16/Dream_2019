//
// Created by redbend on 17/09/2019.
//

#ifndef PART_1_THREAD_FUNCTION_H
#define PART_1_THREAD_FUNCTION_H
void thread_fucntion(){
for(int i=0;i<10;i++){
    std::cout <<"Thead funcito executing \n";
}
}
#endif //PART_1_THREAD_FUNCTION_H
