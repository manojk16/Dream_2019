#include <iostream>
/* 1.
1. we can attach a call back with the thread object this cal lback gets executed when a new thread created.
2. These call back can be
    I. Function Pointer
    II Function Objects:(Functors) - C++ allows the function call operator() to be overloaded, such that an object instantiated from a class can be "called" like a function.
    III Lamda Function
     // Any thread can wait for another to exit by callling join function on that thread object

 * */

// Header for thread class
#include <thread>
#include <iostream>
#include "Thread_function.h"

// 1. Creating a thread using Function Pointer
int main() {
    std::cout << "Hello, MultiThreading world" << std::endl;
    // Thread object can be created likke this
    std::thread thObj(thread_fucntion);
    for(int i=0;i<10;i++)
    std::cout<<"Display from the Main Thread \n";
    thObj.join();
    std::cout << "Exit from the Main fucntion \n";


    return 0;
}