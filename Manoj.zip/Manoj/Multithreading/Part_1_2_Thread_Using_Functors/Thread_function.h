//
// Created by redbend on 17/09/2019.
//

#ifndef PART_2_THREAD_USING_FUNCTORS_THREAD_FUNCTION_H
#define PART_2_THREAD_USING_FUNCTORS_THREAD_FUNCTION_H
class DisplayThread{
public:
    void operator()(){
        for(int i =0;i<10;i++)
        std::cout <<  " Display Thread Execution \n";
    }
};
#endif //PART_2_THREAD_USING_FUNCTORS_THREAD_FUNCTION_H
