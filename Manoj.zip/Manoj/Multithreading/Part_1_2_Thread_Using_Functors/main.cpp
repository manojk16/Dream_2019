#include <iostream>
#include <thread>
#include "Thread_function.h"
int main() {
    std::cout << "Thread using Function Pointers" << std::endl;
    std::thread thobj((DisplayThread()));
    std::this_thread::sleep_for(std::chrono::milliseconds(1));
    for(int i=0;i<10;i++){
        std::cout << "Display from the Main Thread \n";
    }

    std::cout << "Waiting for main thread to Terminate \n";
    thobj.join();
    std::cout << "Main Thread getting out :" <<"\n";
    /*//std::thread Thobj(DisplayThread());
    std::thread thobj(DisplayThread());
    *//*for(int i=0;i<10;i++)
    std::cout << "Display from the Main thread \n";
   std::cout << "Waiting for Main Thread to Terminate \n";
    Thobj.join();
    std::cout << "Main Thread getting out :" <<"\n";*//*
    for(int i=0;i<10;i++)
        std::cout<<"Display from the Main Thread \n";
    thobj().join();
    std::cout << "Exit from the Main fucntion \n";
*/
    return 0;
}