#include <iostream>
#include <thread>
#include <vector>
#include <algorithm>
#include <functional>

// Joining a thread makes one thread of execution wait for another thread to finish running
// joinable :Checks if the thread object identifies an active thread of execution
// 1.  Specifically, returns true if get_id() != std::thread::id()
// 2.  So a default constructed thread is not joinable. if it has been moved from (either constructing another thread object, or assigning to it)-> not joinable . if either of its members join or detach has been called.-> not Joinable


// deatch thread means deatched threads also called the deamon / background threads, deatch function seperates the threads of execution from the threads object and allow it to run independently
// after calling threads *this no longer owns the threads

using namespace std;
class workerThread{
public:
    void operator()(){
        //cout << "In Thread Execution Display "<<endl;
        cout << "Thread executing with thread id " << this_thread::get_id() <<endl;

    }
};
int main() {
    vector<thread> threadlist;

    std::cout << "Hello, Joning and Deatching the Threads!" << std::endl;
    for(int i=0;i<10;i++)
        threadlist.push_back(thread(workerThread()));
//    thread thobj(workerThread()());

//
    cout << "Wait for worker threads to finish " <<endl;
    for_each(threadlist.begin(),threadlist.end(),std::mem_fn(&std::thread::join));
    return 0;
}