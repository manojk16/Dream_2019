cd#include <iostream>
// Assigning pointer to member function of a class as thread function:

#include <thread>
using namespace std;


class dummy{
public:
    dummy(){}
    dummy(const dummy& other){}
    void samplefunction(int x){
        cout << "Insdie sample funciton " << x << endl;
    }

};
int main() {
    std::cout << "Hello, Assigning pointer to member function of a class as thread function!" << std::endl;
    int x=10;
    dummy dummyObj;
    thread thobj(&dummy::samplefunction,&dummyObj,x);
    thobj.join();


    return 0;
}