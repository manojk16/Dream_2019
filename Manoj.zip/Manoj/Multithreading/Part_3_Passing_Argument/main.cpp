#include <iostream>
#include <thread>
using namespace std;
void thread_function(int n, string str){
    cout << " Passed No is " << n << endl;
    cout << " Passed string is " << str << endl;

}
/*
int main() {
    std::cout << "Hello, Passing the argument in thread call back!" << std::endl;
    int x=10;
    string str="Manoj";
    thread thobj(thread_function,x,str);
    if(thobj.joinable()){
        thobj.join();
    }

    return 0;
}*/
// Do not pass the address of the local stack variable in to thread call back functions
// Do not pass the pointer variables to the thread call back function because it may possible that some times another thread can delete heap memory before used by first thread


/******************How to pass reference variable in to threads ***********************/


void thread_fuc(int &x){
    //int &y= const_cast<int &>(x);
    x++;
    cout << "The vaule of x in call back  is " << x <<endl;
}
void thread_fuc_1(const int &x){
    int &y= const_cast<int &>(x);
    y++;
    cout << "The vaule of x in call back  is " << y <<endl;
}
int main(){
    int x=9;
    cout << "Value of s before call back "<< x <<endl;
    thread thobj(thread_fuc, ref(x));
   // thread thobj(thread_fuc, x);
    thobj.join();
    cout << "In main Threads after threds join value of  x is " << x <<endl;
}
