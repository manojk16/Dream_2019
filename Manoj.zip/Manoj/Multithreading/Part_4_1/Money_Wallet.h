//
// Created by redbend on 19/09/2019.
//

#ifndef PART_4_1_MONEY_WALLET_H
#define PART_4_1_MONEY_WALLET_H
#include <iostream>
#include <vector>
#include <thread>
class moneyWallet{
int m_money;
static int count;
public:
    moneyWallet(int money=0):m_money(money){}
    int getMoney(){
        return m_money;
    }
    void addMoney(int money){
        count++;
        for(int i=0;i<money;i++)
        m_money++;
        //std::cout << "No times it is called " << count <<std::endl;
    }
    void print(){
        std::cout << "------------>" << count <<std::endl;
    }

};
int moneyWallet::count=0;
int testMultithreadedWallet(){

    moneyWallet walletObj;
    std::vector<std::thread> threads;
    int j=0;
    for(int i=0;i<5;++i)
    {
        threads.push_back(std::thread(&moneyWallet::addMoney,&walletObj,1000));
    }
    for(int i=0;i<threads.size();++i){
        threads.at(i).join();
    }

    //walletObj.print();
    return walletObj.getMoney();
}
#endif //PART_4_1_MONEY_WALLET_H
