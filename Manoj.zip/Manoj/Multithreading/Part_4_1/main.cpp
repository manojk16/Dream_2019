#include <iostream>
#include "Money_Wallet.h"


// Data Sharing and Race Conditions

// Race Condition : Race Condition occur into multithread program, when 2 more threads perform set of operation in parellel that access ame memory location,Also  one or more threads modify the data  thread modify the data  then
// this can lead to unexpected result and this is called Race Condition

int main() {
    std::cout << "Hello, Data Sharing and Race Conditions!" << std::endl;
    int val=0;
    for(int k=0;k<1000;k++){
        if((val=testMultithreadedWallet())!=5000){
            std::cout << "Error at count = "<<k<<" Money in Wallet = "<<val << std::endl;
        }
    }

    return 0;
}