#ifndef _APPLICATION_H
#define _APPLICATION_H
#include <iostream>
#include <mutex>
#include <condition_variable>
#include <functional>
#include <thread>


using namespace std::placeholders;
class Application{
	std::mutex m_mutex;
	std::condition_variable m_condvar;
	bool m_bdataLoaded;
public:
	Application(){
		m_bdataLoaded=false;
	}
void load_data(){
	// sleep for 1 sec;
	std::this_thread::sleep_for(std::chrono::milliseconds(1000));
	std::cout<<"Loading the data \n";
	//lock
	std::lock_guard<std::mutex> gurad(m_mutex);
	m_bdataLoaded=true;
	//notify the condition_variable
	m_condvar.notify_one();
}
bool isDataLoaded(){
	return m_bdataLoaded;
}
void mainTask(){
	std::cout << "So Some HandShaking\n";
	std::unique_lock<std::mutex> mlock(m_mutex);
	//Start waiting for the Condition Variable to get signaled
	// Wait() will internally release the lock and make the thread to block
	// As soon as condition variable get signaled, resume the thread and
	// again acquire the lock. Then check if condition is met or not
	// If condition is met then continue else again go in wait.
	m_condvar.wait(mlock,std::bind(&Application::isDataLoaded, this));
	std::cout<<"Do Processing on Loaded Data " <<std::endl;
}


};


#endif




