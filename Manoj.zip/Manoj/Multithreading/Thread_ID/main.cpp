#include <iostream>
#include <thread>
void function_1(){
    std::cout << "Inside Thread function ID is " << std::this_thread::get_id()<<std::endl;
}

int main() {
    std::cout << "Hello, World!" << std::endl;
    std::thread thobj1(function_1);
    std::thread thobj2(function_1);
    std::this_thread::sleep_for(std::chrono::microseconds(1));
    if(thobj1.get_id()!=thobj2.get_id()){
        std::cout << "Diferent ID" <<std::endl;
    }
    std::cout << "ID1 ::" << thobj1.get_id()<<std::endl;
    std::cout << "ID2 ::" << thobj2.get_id()<<std::endl;

    std::cout << "Waiting for Terminate \n";
    thobj1.join();
    thobj2.join();


    return 0;
}