#include <iostream>
#include <thread>

int main() {

    std::cout << "Hello, thread using Lambda function!" << std::endl;
    int x=9;
    std::thread thobj([]{
        for(int i=0;i<10;i++){
            std::cout << "Thread Exectuion Display \n";
        }
    });
   // std::this_thread::sleep_for(std::chrono::microseconds(1));
    for(int i =0;i<10;i++)
    std::cout << "Main Thread Execution display \n";

    thobj.join();
    std::cout << "wainting for Main Thread termination \n ";


    return 0;
}