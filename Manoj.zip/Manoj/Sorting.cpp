#include <iostream>
#include <array>
#include <vector>
using namespace std;



class arraylist{
	int m_length;
	int m_maxSize;
	int *m_list;
	void swapitem(int first, int second){
		int temp;
		temp=m_list[first];
		m_list[first]=m_list[second];
		m_list[second]=temp;
	}
	int minLocation(int first, int last){
		int minIndex;
		minIndex=first;
		for(int loc=first+1;loc<last;loc++){
			if(m_list[loc] < m_list[minIndex])
				minIndex=loc;
		}
		return minIndex;
	}
	int partition(int first, int last){
	int pivot=m_list[first];
	int i=first;	
	for(int j=first+1;j<=last;j++){
		if(m_list[j] <= pivot){
			i++;
			swapitem(i,j);
		}
	}
	swapitem(first,i);
	return i;

}
void rquickSort(int first, int last){
	if(first < last){
		int partitionLoc=partition(first,last);
		rquickSort(first,partitionLoc-1);
		rquickSort(partitionLoc+1,last);
	}
}

public:
	arraylist(int size=100){
		m_maxSize=size;
		m_length=0;
		m_list = new int[size];
	}
	//copy constructor
	arraylist(const arraylist& other){
		m_maxSize=other.m_maxSize;
		m_length = other.m_length;
		m_list = new int[other.m_maxSize];
		for(int i=0; i<other.m_length; i++)
		{
			m_list[i]=other.m_list[i];
		}
	}
	// assignment Operatror
	const arraylist& operator=(const arraylist& other){
		if(this!=&other){
			delete [] m_list;
			m_maxSize=other.m_maxSize;
			m_length = other.m_length;
			m_list = new int[other.m_maxSize];
		for(int i=0;i<other.m_length;i++)
			{
				m_list[i]=other.m_list[i];
			}

		}else{
			return *this;
		}
	}
	void insert(int newItem){
		if(m_length==m_maxSize){
			cout << "It is full Not allowed furhter item Insertion \n";
		}
		m_list[m_length++]=newItem;
	}
	void insertAt(int loc, int newItem){
		if(loc < 0 && loc > m_maxSize){
			cout << "Item can not be inserted \n";
		}else if(m_length >= m_maxSize){
			cout << "Array is already filled  \n";
		}else{
			for(int i= m_length;i > loc ;i--){
				m_list[i]=m_list[i-1]; // moved the item one position down 
			}
			m_list[loc]=newItem;
			m_length++;
		}

	}
	// selection sort	
	void selectionSort(){
		int minIndex;
		for(int loc=0;loc<m_length;loc++){
			minIndex=minLocation(loc,m_length);
			swapitem(loc,minIndex);
		}

	}
	int getLength(){
		return m_length;
	}
	void print(){
		for(int i=0;i<m_length;i++){
			cout << m_list[i]<<" ";
		}
		cout << "\n";
	}
	void insertionsort(){

    int firstoutOfOrder,loc;
    int  temp;
    for(firstoutOfOrder=1;firstoutOfOrder<m_length;firstoutOfOrder++){
        if(m_list[firstoutOfOrder]<m_list[firstoutOfOrder-1]){
            temp=m_list[firstoutOfOrder];
            loc=firstoutOfOrder;

        do{
            m_list[loc]=m_list[loc-1];
            loc--;
        }while(loc > 0 && m_list[loc-1] > temp);
        m_list[loc]=temp;
    }
	}

}
// QuickSort

void QuickSort(){
	rquickSort(0,m_length-1);
}

// merge sort 

int rmergeSort(int first, int last, const arraylist &obj){

	int mid= (first+last)/2;
	if(first<last)
	const int sizeL= mid;
	const int sizeR= m_length-mid;
	vector<int> left(sizeL);
	std::vecto<int> right(sizeR);
	//int left[sizeL];
	//int right[sizeR];

	for(int i=0;i<mid-1;i++){
		left[i]=m_list[i];

	}
	for(int i=mid;i<m_length;i++){
		right[i-mid]=
	}
	int lfirst=
	rmergeSort();
	rmergeSort();
	merge(left,right);
}

// merge
void merge(vector<int> &left, vector<int> &right){
//void merge(int left[], int right[], int m_list[]){
	int i=0;// unpicked item of left
	int j=0;// unpicked item of right
	int k=0;// unpicked item of m_list
	int nL=left.size();
	int nR=right.size();

	while(i<nL && j<nR){
		if( left[i] <= right[j]){
			m_list.insertAt(k,left[i]);
			i++;
		}else{
			m_list.insertAt(k,right[j]);
			j++;
		}
		k++;

	}
	while(i<nL){
		m_list.insertAt(k,left[i]);
		k++;
		i++;
	}
	while(j<nR){
		m_list.insertAt(k,right[j]);
		k++;
		j++;
	}


}



void mergeSort(){
	rmergeSort(0,m_length-1);
}

	
};

int main(){
	arraylist array;
	/*array.insert(2);
	array.insert(17);
	array.insert(7);
	array.insert(0);
	array.insert(10);
	array.insert(98);
	array.insert(52);
	array.insert(40);
	array.insert(4);*/
	cout <<"Enter The number not ending with -999\n";
	int num;
	cin >> num;
	while(num!=-999){
		array.insert(num);
		cin >> num;
	}

	cout << "Array before Sorting \n";
	array.print();
	//array.selectionSort();
	// /cout << "Array After Sorting \n";
	//array.QuickSort();
	//array.mergeSort();
	//array.print();
	cout << "lenth of the array is " << array.getLength()<<endl;



}