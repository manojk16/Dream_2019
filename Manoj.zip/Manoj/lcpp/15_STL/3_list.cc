/*
 * 3_list.cc
 *
 *  Created on: Aug 27, 2019
 *      Author: user1
 */


// list :: it is a special type of contianer it is similiar to double linked list
// access to first and last elememt
// no random access
//

