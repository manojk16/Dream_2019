/*
 * 4_Associative_Containers.cc
 *
 *  Created on: Aug 27, 2019
 *      Author: user1
 */
// Associative Containers : Associative container by default sort the values when values inserted into the associative container.
// Associative contianer compare the values by <


// 1. Set: Save the unique value by disallowing duplicates the elements are stored using their values
// 2. MultiSet : Multiset is a associative container which allows the duplicates
// 3. Map :: also called associative array : Map is a set which each element is a pair key/value pair, The key is used for sorting and
// indexing the data and the value is actual data
// 4. MultiMap: also called the dictianry : it allows the duplicates keys Real dictionaries are the multimap where word is the key and meaning is the value






