/*
 * 5_Container_Adapters.cc
 *
 *  Created on: Aug 27, 2019
 *      Author: user1
 */
// Container adpated are specific container like :
// 1. stack : LIFO
// 2. Queue : FIFO
// 3. Priority Queue: A priority queue is a type of queue where the elements are kept sorted (via operator<). When elements are pushed,
// the element is sorted in the queue. Removing an element from the front returns the highest priority item in the priority queue



