/*
 * 1_RelationShip.cc
 *
 *  Created on: Aug 16, 2019
 *      Author: user1
 *
 *      There are different types of relationship between objects and we use specific "relation-type" word to
 *      describe these relationship
 *
 */






