#include <iostream>

using namespace std;

class ArrayNumSum{
	int m_length;
	int *m_arr;
	int m_maxSize;
public:
	
	ArrayNumSum(int size){
		m_length= 0;
		m_maxSize=size;
		m_arr= new int [m_maxSize];

	}
 ArrayNumSum(const ArrayNumSum &obj){
 	m_length= obj.m_length;
 	m_maxSize=obj.m_maxSize;
 	m_arr=new int [obj.m_length];
 	for(int i=0;i<m_length;i++){
 		m_arr[i]=obj.m_arr[i];
 	}
 }

 ArrayNumSum& operator=(const ArrayNumSum &obj){
 	if(&obj!=this){
 		delete [] m_arr;
 		m_length= obj.m_length;
 		m_maxSize=obj.m_maxSize;
 		for(int i=0;i<m_length;i++){
 		m_arr[i]=obj.m_arr[i];
 		}
 	}else{
 	return *this;
 	}
 }

 void insert(int newItem){
 	if(m_length==0)
 		m_arr[m_length++]= newItem;
 	else if(m_length==m_maxSize)
 		cout << "Can Not inserted \n";
 	else{
 		m_arr[m_length++] = newItem;
 	}
 }
 void print(){
 	for(int i=0;i<m_length;i++){
 		cout << m_arr[i] << ",";
 	}
 	cout << endl;
 }
};
int main(){
	/*int arr[]={1,2,3};
	int arr_1[]={2,1,4,5};

	int num=0;
	int num2=0;
	int mult=1;
	int mult1=1;
	for(int i=2;i>=0;i--){
		num += arr[i]*mult;
		mult = mult*10;	

	}

	for(int i=3;i>=0;i--){
		num2 += arr_1[i]*mult1;
		mult1 = mult1*10;	

	}

	int sum= num+num2;

	cout << "num is : " << num <<endl;
	cout << "num2 is " << num2 <<endl;
	cout << "Sum is " << sum << endl;*/

	ArrayNumSum *arrobj = new ArrayNumSum(10);
	arrobj->insert(1);
	arrobj->insert(2);
	arrobj->insert(3);
	arrobj->print();	
	return 0;
}