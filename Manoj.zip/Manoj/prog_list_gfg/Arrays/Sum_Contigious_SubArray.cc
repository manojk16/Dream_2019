#include <iostream>
#include <cmath>
#include <climits>
#include <algorithm>
using namespace std;

// Basic Method with Cubic Complexity 
int maxSumSubArray(int arr[], int n){

int maximumSubArraySum = INT_MIN;

	for(int left=0;left < n ; left++){

		for(int right = left ; right < n ; right ++){

			int windowsSum=0;

			for(int k=left; k<=right ; k++){

				windowsSum += arr[k];

			}
			maximumSubArraySum= max(maximumSubArraySum,windowsSum);

		}
	}

	return maximumSubArraySum;
}


int maxSumSubArray_Quadratic(int arr[], int n){
	int maximumSubArraySum=INT_MIN;

	for(int left=0; left < n ; left ++){

		int MovingWindowsSum=0;
		for(int right =left; right < n ; right++){
			MovingWindowsSum += arr[right];
			maximumSubArraySum=max(MovingWindowsSum,maximumSubArraySum);
		}
		
	}

	return maximumSubArraySum;
}


void leftRoatebyOne(int arr[], int n){
	int temp = arr[0];
	//int i;
	for(int i=0;i<n-1;++i){
		arr[i]=arr[i+1];
	}
	arr[n-1]=temp;
}

void leftRotate(int arr[], int n, int d){

	for(int i=0;i<d;++i){
		leftRoatebyOne(arr,n);
	}

}

void printArray(int arr[], int n){
	for(int i=0;i<n;i++){
		cout << arr[i] << " "  ;
	} 
	cout << endl;

}
int main(){
   //	cout << "Min Value is " << INT_MIN  << endl;

	int arr[]={-2, -3, 4, -1, -2, 1, 5, -3};
	int size_Array = sizeof(arr)/sizeof(int) ;
	cout << "Array Before Reverse " <<endl;
	printArray(arr,size_Array);
	cout << "Max sum is  " << maxSumSubArray(arr,size_Array)<<endl;

	cout << "Max sum is using quadrativ Time Complexity is  " << maxSumSubArray_Quadratic(arr,size_Array)<<endl;

	leftRotate(arr,size_Array,2);
	printArray(arr,size_Array);
}