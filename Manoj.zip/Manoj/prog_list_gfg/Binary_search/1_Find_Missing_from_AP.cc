/*

Algorithm: 
1. if Missing element is just after the mid then : 
if(arr[mid+1]-arr[mid]!=diff ){
	return (arr[mid] + diff)
}
2. if Missing element is just before the mid element 
if(mid > 0 && arr[mid]-arr[mid-1]!=diff)
	return (arr[mid-1]+diff)

3. if Ap is in sequence till mid 
	if(arr[mid] == arr[0] + mid*diff)
		// search on the right half 
	else 
	search in the left haf

*/


#include <iostream>
#include <climits>
#include <vector>
#include <algorithm>
#include <array>

using namespace std;


class FindMission{
private:
	bool BinarySearch(int arr[], int start, int end, int item);

public:
	int findMissingItem(int arr[], int low, int high, int diff){
		int mid=(low+high)/2;
		if(high <= low)
			return INT_MIN;
		// Item exist k=just after the mid 
		if(arr[mid+1]-arr[mid]!=diff){
			return (arr[mid]+diff);
		} 
		// item exist just before the mid
		else if( mid > 0 && (arr[mid] - arr[mid-1] )!=diff){
			return (arr[mid-1]+diff);
		}
		// If elements follow AP till mid then rec=urrance in 2md half.
		if(arr[mid]=arr[0]+mid*diff)
			return findMissingItem(arr,low,mid-1,diff);
		else
		// recurrence left half
			return findMissingItem(arr,mid+1,high,diff);

	}

	int finddiff(int arr[], int n){
		int diff = (arr[n-1]-arr[0])/n;
		return findMissingItem(arr,0,n-1,diff);
	}

	int CountNDistinctPairsWithDifferenceKCountBinarySearch(int arr[], int n,int k);
	int CountNDistinctPairsWithDifferenceKCount(int arr[], int n,int k);
	int CountNDistinctPairsWithDifferenceKCountSorting(int arr[], int n,int k);
};


bool FindMission::BinarySearch(int arr[], int l, int r, int k){
	int mid=(l+r)/2;
	if(l>r)
		return false;
	if(arr[mid]==k){
		return true;
	}
	if(arr[mid] > k){
		return BinarySearch(arr,l,mid-1,k);
	}else{
		return BinarySearch(arr,mid+1,r,k);
	}
}

// With Complexity o(nlogn)
int FindMission::CountNDistinctPairsWithDifferenceKCountBinarySearch(int arr[], int n,int k){
	// sort the Array for Binary search
	sort(arr,arr+n);
	int count=0;
	for(int i=0;i<n;++i){
		bool result=BinarySearch(arr, i+1,n-1,arr[i]+k);
		if(result){
			count++;
		}

	}
	return count;

}
// With Complexity O(n^2)
int FindMission::CountNDistinctPairsWithDifferenceKCount(int arr[], int n,int k){

	int count =0;
	for(int i=0;i<n;++i){

		for(int j=i+1;j<n;++j){

			if(arr[i]-arr[j] == k || arr[j]-arr[i]==k){
				count++;
			}
		}
	}
	return count;
}
// With Complexity O(nlogn)

int FindMission::CountNDistinctPairsWithDifferenceKCountSorting(int arr[],int n,int k){
	sort(arr,arr+n);
	int count =0 ;
	int l=0;
	int r=0;
	while(r<n){
		if(arr[r]-arr[l]==k){
			count++;
			l++;
			r++;
		}else if(arr[r]-arr[l] > k){
			l++;

		}else{
			r++;
		}
	}
	return count;
}
int main(){
	FindMission obj;
	/*int arr[]={2,4,8,10,12,14};
	int n=sizeof(arr)/sizeof(int);
	cout << "The missing element is " << obj.finddiff(arr,n)<< endl;*/

	int arr1[] = {1,2,3,4,5,7,9};
	int size=sizeof(arr1)/sizeof(int);
	cout << "The Total Number of  Pair is :: " << obj.CountNDistinctPairsWithDifferenceKCountBinarySearch(arr1,size,3)<<endl;
	cout << "The Total Number of  Pair is (Count ):: " << obj.CountNDistinctPairsWithDifferenceKCount(arr1,size,3)<<endl;
	 cout << "The Total Number of  Pair is (Sorting ):: " << obj.CountNDistinctPairsWithDifferenceKCountSorting(arr1,size,3)<<endl;

	
	return 0;
}