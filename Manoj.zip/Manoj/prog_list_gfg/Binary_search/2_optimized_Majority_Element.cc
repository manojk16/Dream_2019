// There are two methods One is Binary Srarch and onther is Morre's Voting Method 
// In Binary Search Method We have to give the Majority Element 
// While By Morre's Voting Method we can find out the duplicate Element 

#include <iostream>
#include<vector>

using namespace std;


class findMajority{
private:
	bool isMajority(int arr[],int size, int cand);
public:

	int findCandidate(int arr[],int size);
	void printMajorityElement(int arr[],int size);


};


int findMajority::findCandidate(int arr[],int size){
	int count=1;
	int Majority_index=0;
	for(int i=1;i<size;i++){
		if(arr[Majority_index]==arr[i]){
			count++;
		}else{
			count--;
		} 
		if(count==0){
			Majority_index=i;
			count=1;
		}

	}
	return arr[Majority_index];
}


bool findMajority::isMajority(int arr[],int size,int cand){
	int count=0;
	for(int i=0;i<size;i++){
		if(arr[i]==cand){
			count++;
		}
	}
	if(count > size/2){
		return true;
	}
	else{
		return false;
	}


}
void findMajority::printMajorityElement(int arr[],int size){

	int cand=findCandidate(arr,size);

	if(isMajority(arr,size,cand)){
		cout << "The Mjority Element is " << cand <<endl;
	}
	else{
		cout << "No Majority Element \n";
	}
}


int main(){

	findMajority obj;
	//int arr[]={1, 3, 3, 1, 2};
	int arr[]={1,2,2,2,2,2,5,7,7};
	int size=sizeof(arr)/sizeof(int);
	// Using Morre's Voting Method.
	obj.printMajorityElement(arr,size);

	// Using Binary search method 

	
	return 0;
}